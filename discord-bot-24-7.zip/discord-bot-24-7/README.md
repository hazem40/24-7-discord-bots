# Discord Bot 24/7

This is a basic Discord bot that stays online 24/7 using a lightweight web server.

## 🚀 How to Use

1. Clone this repo.
2. Install packages:

   ```bash
   npm install
   ```

3. Set your bot token securely:

   - Locally via `.env` (create one with `TOKEN=your_token_here`)
   - Or in Replit/Railway as environment variable

4. Start the bot:

   ```bash
   node index.js
   ```

5. Use `!ping` in any server channel to check if it's working.

## 🟢 Hosting

- ✅ **Replit**: Add `keepAlive.js` + `UptimeRobot` ping every 5 minutes
- ✅ **Railway**: Automatically stays online with deployment
